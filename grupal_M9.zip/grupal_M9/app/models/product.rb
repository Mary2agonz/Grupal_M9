class Product < ApplicationRecord
  belongs_to :user
end
